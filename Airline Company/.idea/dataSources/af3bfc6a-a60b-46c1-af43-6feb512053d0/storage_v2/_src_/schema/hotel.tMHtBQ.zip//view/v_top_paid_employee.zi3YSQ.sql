create view v_top_paid_employee as
select `hotel`.`employees`.`salary` AS `salary`
from `hotel`.`employees`
order by `hotel`.`employees`.`salary` desc
limit 1;

